package com.uibtech.psbproject

class DataModel(
        val title: String, val dscr: String, val albm: String)