package com.uibtech.psbproject

import android.os.Bundle
import android.util.Log
import android.view.Menu
import android.view.MenuItem
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.Toolbar
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout
import com.android.volley.Request
import com.android.volley.Response
import com.android.volley.toolbox.StringRequest
import com.android.volley.toolbox.Volley
import com.google.android.material.snackbar.Snackbar
import org.json.JSONException
import org.json.JSONObject
import java.util.*

class MainActivity : AppCompatActivity() {
    var listAdapter: ListAdapter? = null
    private val firstTime = true
    var recyclerView: RecyclerView? = null
    var toolbar: Toolbar? = null
    var arrayList: ArrayList<DataModel>? = null
    var refreshLayout: SwipeRefreshLayout? = null
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        initView()
        dataJSON
        refreshLayout()
    }

    private fun refreshLayout() {
        refreshLayout!!.setOnRefreshListener {
            adapterSetup()
            refreshLayout!!.isRefreshing = false
            Snackbar.make(window.decorView.rootView, "Item has been refreshed", Snackbar.LENGTH_LONG).show()
        }
    }

    //getting title for actionBar
    private val dataJSON: Unit
        private get() {
            val url = "https://dl.dropboxusercontent.com/s/2iodh4vg0eortkl/facts.json"
            arrayList = ArrayList()
            val stringRequest = StringRequest(Request.Method.GET,
                    url, Response.Listener { response ->
                Log.i("TAG", "onResponse : $arrayList")
                if (response != null) {
                    Log.i("TAG", "onResponse : $response")
                    try {
                        val o = JSONObject(response)
                        val jsonArray = o.getJSONArray("rows")
                        val titleAc = o.getString("title") //getting title for actionBar
                        toolbar!!.title = titleAc
                        for (i in 0 until jsonArray.length()) {
                            val data = jsonArray.getJSONObject(i)
                            arrayList!!.add(DataModel(data.getString("title"),
                                    data.getString("description"),
                                    data.getString("imageHref")))
                        }
                        adapterSetup()
                    } catch (r: JSONException) {
                        r.printStackTrace()
                    }
                }
            }, Response.ErrorListener { error ->
                Log.i("TAG", "onErrorResponse : $error")
                Toast.makeText(this@MainActivity, "" + error, Toast.LENGTH_LONG).show()
            })
            Volley.newRequestQueue(this).add(stringRequest)
            Log.i("tag", "onErrorResponse : $stringRequest")
        }

    private fun adapterSetup() {
        listAdapter = ListAdapter(arrayList!!, this)
        recyclerView!!.layoutManager = LinearLayoutManager(this)
        recyclerView!!.adapter = listAdapter
        recyclerView!!.setHasFixedSize(true)
        recyclerView!!.setItemViewCacheSize(arrayList!!.size)
    }

    private fun initView() {
        recyclerView = findViewById(R.id.recyclerView)
        refreshLayout = findViewById(R.id.swipeLayout)
        toolbar = findViewById(R.id.toolbar)
        setSupportActionBar(toolbar)
    }

    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        menuInflater.inflate(R.menu.menu, menu)
        return super.onCreateOptionsMenu(menu)
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        if (item.itemId == R.id.refBtn) {
            adapterSetup()
            Snackbar.make(window.decorView.rootView, "Item has been refreshed", Snackbar.LENGTH_LONG).show()
        }
        return super.onOptionsItemSelected(item)
    }
}